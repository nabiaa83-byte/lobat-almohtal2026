import type { ReactNode } from 'react';
import { View } from 'react-native';

import { colors } from '@/theme';

export function Card({ children }: { children: ReactNode }) {
  return (
    <View
      style={{
        backgroundColor: colors.card,
        borderRadius: 20,
        borderCurve: 'continuous',
        padding: 16,
        gap: 12,
        boxShadow: '0 1px 2px rgba(0, 0, 0, 0.06)',
      }}>
      {children}
    </View>
  );
}
