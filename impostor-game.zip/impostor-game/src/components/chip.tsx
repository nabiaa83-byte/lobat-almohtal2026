import { Pressable } from 'react-native';

import { Text } from '@/components/text';
import { colors } from '@/theme';
import { tap } from '@/utils/haptics';

type Props = {
  label: string;
  selected: boolean;
  onPress: () => void;
  /** نمط الاختيار: اختيار متعدد أم واحد فقط. */
  role?: 'checkbox' | 'radio';
};

export function Chip({ label, selected, onPress, role = 'checkbox' }: Props) {
  return (
    <Pressable
      accessibilityRole={role}
      accessibilityLabel={label}
      accessibilityState={{ checked: selected }}
      onPress={() => {
        tap();
        onPress();
      }}
      style={({ pressed }) => ({
        backgroundColor: selected ? colors.accent : colors.background,
        borderWidth: 1,
        borderColor: selected ? colors.accent : colors.separator,
        borderRadius: 999,
        paddingHorizontal: 16,
        paddingVertical: 10,
        opacity: pressed ? 0.7 : 1,
      })}>
      <Text size={16} weight="600" color={selected ? '#ffffff' : colors.label}>
        {label}
      </Text>
    </Pressable>
  );
}
