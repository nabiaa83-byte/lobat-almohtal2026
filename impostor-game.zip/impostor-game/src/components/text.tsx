import { Text as RNText, type ColorValue, type TextProps } from 'react-native';

import { colors } from '@/theme';

type Props = TextProps & {
  size?: number;
  weight?: '400' | '500' | '600' | '700' | '800';
  color?: ColorValue;
  muted?: boolean;
  center?: boolean;
};

export function Text({
  size = 17,
  weight = '400',
  color,
  muted = false,
  center = false,
  style,
  ...rest
}: Props) {
  return (
    <RNText
      {...rest}
      style={[
        {
          fontSize: size,
          fontWeight: weight,
          color: color ?? (muted ? colors.secondaryLabel : colors.label),
          textAlign: center ? 'center' : 'auto',
        },
        style,
      ]}
    />
  );
}
