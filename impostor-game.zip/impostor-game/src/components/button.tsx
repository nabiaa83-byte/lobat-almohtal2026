import { Pressable } from 'react-native';

import { Text } from '@/components/text';
import { colors } from '@/theme';
import { tap } from '@/utils/haptics';

type Props = {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  disabled?: boolean;
  small?: boolean;
};

export function Button({ title, onPress, variant = 'primary', disabled = false, small = false }: Props) {
  const background =
    variant === 'primary'
      ? colors.accent
      : variant === 'danger'
        ? colors.danger
        : variant === 'secondary'
          ? colors.card
          : 'transparent';
  const foreground =
    variant === 'primary' || variant === 'danger'
      ? '#ffffff'
      : variant === 'ghost'
        ? colors.accent
        : colors.label;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      accessibilityState={{ disabled }}
      disabled={disabled}
      onPress={() => {
        tap();
        onPress();
      }}
      style={({ pressed }) => ({
        backgroundColor: background,
        opacity: disabled ? 0.4 : pressed ? 0.75 : 1,
        minHeight: small ? 44 : 56,
        paddingHorizontal: 20,
        borderRadius: 16,
        borderCurve: 'continuous',
        alignItems: 'center',
        justifyContent: 'center',
      })}>
      <Text weight="700" size={small ? 16 : 19} color={foreground} center>
        {title}
      </Text>
    </Pressable>
  );
}
