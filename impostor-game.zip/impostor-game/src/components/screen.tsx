import type { ReactNode } from 'react';
import { ScrollView } from 'react-native';

import { colors } from '@/theme';

type Props = {
  children: ReactNode;
  /** توسيط المحتوى عمودياً (لشاشات الدور والكشف). */
  center?: boolean;
};

/** حاوية الشاشة: تمرير تلقائي مع احترام المناطق الآمنة، واتجاه من اليمين لليسار. */
export function Screen({ children, center = false }: Props) {
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentInsetAdjustmentBehavior="automatic"
      keyboardShouldPersistTaps="handled"
      automaticallyAdjustKeyboardInsets
      contentContainerStyle={{
        flexGrow: 1,
        padding: 16,
        gap: 16,
        direction: 'rtl',
        justifyContent: center ? 'center' : 'flex-start',
      }}>
      {children}
    </ScrollView>
  );
}
