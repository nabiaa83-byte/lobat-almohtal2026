import { useState } from 'react';
import { Pressable, View } from 'react-native';

import { Button } from '@/components/button';
import { Text } from '@/components/text';
import { PIN_LENGTH } from '@/constants';
import { colors } from '@/theme';
import { fail, tap } from '@/utils/haptics';

type Props = {
  title: string;
  hint?: string;
  expectedPin: string;
  onSuccess: () => void;
  onCancel?: () => void;
};

const ROWS = [
  ['1', '2', '3'],
  ['4', '5', '6'],
  ['7', '8', '9'],
];

/** لوحة إدخال رمز الحكم. تتحقق من الرمز عند اكتمال الأرقام. */
export function PinPad({ title, hint, expectedPin, onSuccess, onCancel }: Props) {
  const [value, setValue] = useState('');
  const [wrong, setWrong] = useState(false);

  function press(digit: string) {
    if (value.length >= PIN_LENGTH) return;
    const next = value + digit;
    setWrong(false);
    setValue(next);
    tap();
    if (next.length < PIN_LENGTH) return;
    if (next === expectedPin) {
      onSuccess();
      return;
    }
    fail();
    setWrong(true);
    setTimeout(() => setValue(''), 300);
  }

  function erase() {
    setWrong(false);
    setValue((current) => current.slice(0, -1));
    tap();
  }

  return (
    <View style={{ alignItems: 'center', gap: 20, width: '100%' }}>
      <Text size={24} weight="800" center>
        {title}
      </Text>
      {hint ? (
        <Text muted center>
          {hint}
        </Text>
      ) : null}

      <View
        accessibilityLabel={`تم إدخال ${value.length} من ${PIN_LENGTH} أرقام`}
        style={{ flexDirection: 'row', gap: 14, direction: 'ltr' }}>
        {Array.from({ length: PIN_LENGTH }, (_, i) => (
          <View
            key={i}
            style={{
              width: 16,
              height: 16,
              borderRadius: 8,
              backgroundColor: i < value.length ? (wrong ? colors.danger : colors.accent) : colors.separator,
            }}
          />
        ))}
      </View>

      <Text color={colors.danger} center style={{ minHeight: 22 }}>
        {wrong ? 'الرمز غير صحيح' : ' '}
      </Text>

      {/* لوحة الأرقام تبقى بترتيبها المعتاد (1 2 3 من اليسار) */}
      <View style={{ gap: 12, direction: 'ltr' }}>
        {ROWS.map((row) => (
          <View key={row.join('')} style={{ flexDirection: 'row', gap: 12 }}>
            {row.map((digit) => (
              <Key key={digit} label={digit} onPress={() => press(digit)} />
            ))}
          </View>
        ))}
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <Key label="⌫" accessibilityLabel="حذف" onPress={erase} />
          <Key label="0" onPress={() => press('0')} />
          <View style={{ width: 72, height: 72 }} />
        </View>
      </View>

      {onCancel ? <Button title="إلغاء" variant="ghost" small onPress={onCancel} /> : null}
    </View>
  );
}

function Key({
  label,
  onPress,
  accessibilityLabel,
}: {
  label: string;
  onPress: () => void;
  accessibilityLabel?: string;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel ?? label}
      onPress={onPress}
      style={({ pressed }) => ({
        width: 72,
        height: 72,
        borderRadius: 36,
        backgroundColor: colors.card,
        alignItems: 'center',
        justifyContent: 'center',
        opacity: pressed ? 0.6 : 1,
      })}>
      <Text size={28} weight="600" center>
        {label}
      </Text>
    </Pressable>
  );
}
