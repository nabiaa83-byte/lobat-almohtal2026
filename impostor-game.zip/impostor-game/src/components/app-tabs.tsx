import { NativeTabs } from 'expo-router/native-tabs';

export default function AppTabs() {
  return (
    <NativeTabs>
      <NativeTabs.Trigger name="(game)">
        <NativeTabs.Trigger.Label>اللعبة</NativeTabs.Trigger.Label>
        <NativeTabs.Trigger.Icon sf="gamecontroller.fill" md="sports_esports" />
      </NativeTabs.Trigger>

      <NativeTabs.Trigger name="(results)">
        <NativeTabs.Trigger.Label>النتائج</NativeTabs.Trigger.Label>
        <NativeTabs.Trigger.Icon sf="trophy.fill" md="emoji_events" />
      </NativeTabs.Trigger>
    </NativeTabs>
  );
}
