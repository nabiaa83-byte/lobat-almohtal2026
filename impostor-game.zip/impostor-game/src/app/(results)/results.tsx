import { Results } from '@/screens/results';

export default function ResultsRoute() {
  return <Results />;
}
