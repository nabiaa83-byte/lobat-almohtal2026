import { Stack } from 'expo-router/stack';

export default function ResultsLayout() {
  return (
    <Stack>
      <Stack.Screen name="results" options={{ title: 'النتائج' }} />
    </Stack>
  );
}
