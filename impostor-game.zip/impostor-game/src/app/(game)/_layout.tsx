import { Stack } from 'expo-router/stack';

export default function GameLayout() {
  return (
    <Stack>
      <Stack.Screen name="index" options={{ title: 'من هو المحتال؟' }} />
    </Stack>
  );
}
