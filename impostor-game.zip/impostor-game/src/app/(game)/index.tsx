import { Game } from '@/screens/game';

export default function GameRoute() {
  return <Game />;
}
