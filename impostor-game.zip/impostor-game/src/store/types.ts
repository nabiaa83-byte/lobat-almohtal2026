import type { CategoryId } from '@/constants/words';

export type Settings = {
  /** رمز الحكم (4 أرقام). */
  pin: string;
  /** طلب رمز الحكم عند كل انتقال بين اللاعبين. */
  lockBetweenPlayers: boolean;
  /** وقت كل لاعب في النقاش بالثواني. */
  speakSeconds: number;
  /** هل يرى المحتال اسم الفئة؟ */
  impostorSeesCategory: boolean;
  categories: CategoryId[];
  /** أسماء اللاعبين المحفوظة بين الجولات. */
  players: string[];
};

export type PlayerStats = {
  points: number;
  rounds: number;
  asImpostor: number;
  caught: number;
};

export type RoundRecord = {
  id: string;
  at: number;
  category: CategoryId;
  word: string;
  impostor: string;
  players: string[];
  voted: string;
  caught: boolean;
};

export type Persisted = {
  settings: Settings;
  scores: Record<string, PlayerStats>;
  history: RoundRecord[];
  /** من أصبحوا محتالين في الدورة الحالية. */
  impostorDone: string[];
  lastImpostor: string | null;
  usedWords: string[];
};

export type Phase =
  | 'setup'
  | 'pass'
  | 'reveal'
  | 'lock'
  | 'ready'
  | 'discuss'
  | 'vote'
  | 'outcome';

export type Session = {
  phase: Phase;
  players: string[];
  revealOrder: string[];
  speakOrder: string[];
  /** رقم اللاعب الحالي في مرحلة كشف الأدوار. */
  index: number;
  impostor: string;
  category: CategoryId;
  word: string;
  voted: string | null;
};
