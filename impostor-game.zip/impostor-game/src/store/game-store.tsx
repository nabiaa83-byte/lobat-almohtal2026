import { createContext, use, useEffect, useState, type ReactNode } from 'react';

import { HISTORY_LIMIT } from '@/constants';
import { CATEGORY_IDS, type CategoryId } from '@/constants/words';
import { drawImpostor, drawWord, shuffle } from '@/utils/draw';
import { applyRound } from '@/utils/scoring';
import { storage } from '@/utils/storage';

import type { Persisted, RoundRecord, Session, Settings } from './types';

const STORAGE_KEY = 'impostor-game:v1';

const DEFAULT_SETTINGS: Settings = {
  pin: '',
  lockBetweenPlayers: true,
  speakSeconds: 30,
  impostorSeesCategory: true,
  categories: [...CATEGORY_IDS],
  players: [],
};

const DEFAULT_DATA: Persisted = {
  settings: DEFAULT_SETTINGS,
  scores: {},
  history: [],
  impostorDone: [],
  lastImpostor: null,
  usedWords: [],
};

const EMPTY_SESSION: Session = {
  phase: 'setup',
  players: [],
  revealOrder: [],
  speakOrder: [],
  index: 0,
  impostor: '',
  category: CATEGORY_IDS[0],
  word: '',
  voted: null,
};

/** يقرأ البيانات المحفوظة ويدمجها مع القيم الافتراضية بأمان. */
function load(): Persisted {
  const saved = storage.get<Partial<Persisted>>(STORAGE_KEY, {});
  const settings: Settings = { ...DEFAULT_SETTINGS, ...saved.settings };
  const categories = Array.isArray(settings.categories)
    ? settings.categories.filter((id): id is CategoryId => CATEGORY_IDS.includes(id))
    : [];
  return {
    ...DEFAULT_DATA,
    ...saved,
    settings: {
      ...settings,
      categories: categories.length > 0 ? categories : [...CATEGORY_IDS],
      players: Array.isArray(settings.players) ? settings.players : [],
    },
  };
}

type GameStore = {
  data: Persisted;
  session: Session;
  updateSettings: (patch: Partial<Settings>) => void;
  startRound: (players: string[]) => void;
  showWord: () => void;
  hideWord: () => void;
  nextPlayer: () => void;
  startDiscussion: () => void;
  startVote: () => void;
  chooseVote: (name: string) => void;
  revealOutcome: () => void;
  finishRound: () => void;
  abortRound: () => void;
  resetResults: () => void;
};

const GameContext = createContext<GameStore | null>(null);

export function GameProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Persisted>(load);
  const [session, setSession] = useState<Session>(EMPTY_SESSION);

  useEffect(() => {
    storage.set(STORAGE_KEY, data);
  }, [data]);

  const store: GameStore = {
    data,
    session,

    updateSettings: (patch) =>
      setData((prev) => ({ ...prev, settings: { ...prev.settings, ...patch } })),

    startRound: (players) => {
      const impostor = drawImpostor(players, data.impostorDone, data.lastImpostor);
      const word = drawWord(data.settings.categories, data.usedWords);
      setData({
        ...data,
        settings: { ...data.settings, players },
        impostorDone: impostor.done,
        lastImpostor: impostor.impostor,
        usedWords: word.used,
      });
      setSession({
        phase: 'pass',
        players,
        revealOrder: shuffle(players),
        speakOrder: shuffle(players),
        index: 0,
        impostor: impostor.impostor,
        category: word.category,
        word: word.word,
        voted: null,
      });
    },

    showWord: () => setSession((s) => ({ ...s, phase: 'reveal' })),

    nextPlayer: () =>
      setSession((s) =>
        s.index + 1 >= s.revealOrder.length
          ? { ...s, phase: 'ready' }
          : { ...s, phase: 'pass', index: s.index + 1 },
      ),

    hideWord: () => {
      if (data.settings.lockBetweenPlayers) {
        setSession((s) => ({ ...s, phase: 'lock' }));
      } else {
        store.nextPlayer();
      }
    },

    startDiscussion: () => setSession((s) => ({ ...s, phase: 'discuss' })),
    startVote: () => setSession((s) => ({ ...s, phase: 'vote', voted: null })),
    chooseVote: (name) => setSession((s) => ({ ...s, voted: name })),
    revealOutcome: () =>
      setSession((s) => (s.voted ? { ...s, phase: 'outcome' } : s)),

    finishRound: () => {
      if (!session.voted) return;
      const record: RoundRecord = {
        id: String(Date.now()),
        at: Date.now(),
        category: session.category,
        word: session.word,
        impostor: session.impostor,
        players: session.players,
        voted: session.voted,
        caught: session.voted === session.impostor,
      };
      setData({
        ...data,
        scores: applyRound(data.scores, record),
        history: [record, ...data.history].slice(0, HISTORY_LIMIT),
      });
      setSession(EMPTY_SESSION);
    },

    abortRound: () => setSession(EMPTY_SESSION),

    resetResults: () =>
      setData({
        ...data,
        scores: {},
        history: [],
        impostorDone: [],
        lastImpostor: null,
        usedWords: [],
      }),
  };

  return <GameContext value={store}>{children}</GameContext>;
}

export function useGame(): GameStore {
  const store = use(GameContext);
  if (!store) throw new Error('useGame must be used inside GameProvider');
  return store;
}
