import { useState, type ReactNode } from 'react';
import { ScrollView } from 'react-native';

import { PinPad } from '@/components/pin-pad';
import { PIN_LENGTH } from '@/constants';
import { colors } from '@/theme';

type Pending = { title: string; action: () => void };

/**
 * بوابة رمز الحكم: `ask(title, action)` تعرض لوحة الرمز فوق الشاشة،
 * وتنفّذ `action` فقط عند إدخال الرمز الصحيح. ضع `overlay` في آخر الشاشة.
 */
export function usePinGate(pin: string): {
  ask: (title: string, action: () => void) => void;
  overlay: ReactNode;
} {
  const [pending, setPending] = useState<Pending | null>(null);

  function ask(title: string, action: () => void) {
    if (pin.length !== PIN_LENGTH) {
      // لم يُضبط رمز بعد (مثلاً في شاشة النتائج قبل أول جولة)
      action();
      return;
    }
    setPending({ title, action });
  }

  const overlay = pending ? (
    <ScrollView
      style={{
        position: 'absolute',
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        backgroundColor: colors.background,
      }}
      contentInsetAdjustmentBehavior="automatic"
      contentContainerStyle={{
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 24,
        direction: 'rtl',
      }}>
      <PinPad
        title={pending.title}
        hint="أدخل رمز الحكم للمتابعة"
        expectedPin={pin}
        onCancel={() => setPending(null)}
        onSuccess={() => {
          const run = pending.action;
          setPending(null);
          run();
        }}
      />
    </ScrollView>
  ) : null;

  return { ask, overlay };
}
