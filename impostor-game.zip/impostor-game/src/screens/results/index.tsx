import { View } from 'react-native';

import { Button } from '@/components/button';
import { Card } from '@/components/card';
import { Screen } from '@/components/screen';
import { Text } from '@/components/text';
import { POINTS_CAUGHT, POINTS_ESCAPED } from '@/constants';
import { getCategory } from '@/constants/words';
import { usePinGate } from '@/hooks/use-pin-gate';
import { useGame } from '@/store/game-store';
import { colors } from '@/theme';
import { ranking } from '@/utils/scoring';

export function Results() {
  const { data, resetResults } = useGame();
  const { ask, overlay } = usePinGate(data.settings.pin);
  const board = ranking(data.scores);

  return (
    <View style={{ flex: 1 }}>
      <Screen>
        {board.length === 0 ? (
          <Card>
            <Text size={22} weight="700" center>
              لا توجد نتائج بعد
            </Text>
            <Text muted center>
              العبوا جولة كاملة وسيظهر الترتيب والسجل هنا.
            </Text>
          </Card>
        ) : (
          <>
            <Card>
              <Text size={20} weight="700">
                الترتيب
              </Text>
              {board.map(([name, stats], i) => (
                <View
                  key={name}
                  style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 4 }}>
                  <Text size={20} weight="800" color={colors.accent} style={{ width: 28 }}>
                    {i + 1}
                  </Text>
                  <View style={{ flex: 1 }}>
                    <Text weight="700" selectable>
                      {name}
                    </Text>
                    <Text muted size={14}>
                      محتال {stats.asImpostor} مرة · كُشف {stats.caught} · لعب {stats.rounds} جولة
                    </Text>
                  </View>
                  <Text
                    size={24}
                    weight="800"
                    selectable
                    style={{ fontVariant: ['tabular-nums'] }}>
                    {stats.points}
                  </Text>
                </View>
              ))}
              <Text muted size={13}>
                كشف المحتال: {POINTS_CAUGHT} نقطة لكل لاعب عداه · نجاة المحتال: {POINTS_ESCAPED} نقطتان له
              </Text>
            </Card>

            <Card>
              <Text size={20} weight="700">
                سجل الجولات
              </Text>
              {data.history.map((round, i) => (
                <View
                  key={round.id}
                  style={{
                    gap: 2,
                    paddingTop: 10,
                    borderTopWidth: i === 0 ? 0 : 1,
                    borderTopColor: colors.separator,
                  }}>
                  <Text weight="700">
                    الجولة {data.history.length - i} · {getCategory(round.category).label}
                  </Text>
                  <Text selectable>الكلمة: {round.word}</Text>
                  <Text selectable>
                    المحتال: {round.impostor} ·{' '}
                    <Text weight="700" color={round.caught ? colors.success : colors.danger}>
                      {round.caught ? 'كُشف' : 'نجا'}
                    </Text>
                  </Text>
                </View>
              ))}
            </Card>

            <Button
              title="مسح كل النتائج"
              variant="danger"
              onPress={() => ask('مسح كل النتائج', resetResults)}
            />
          </>
        )}
      </Screen>
      {overlay}
    </View>
  );
}
