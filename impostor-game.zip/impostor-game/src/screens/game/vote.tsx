import { View } from 'react-native';

import { Button } from '@/components/button';
import { Card } from '@/components/card';
import { Chip } from '@/components/chip';
import { Screen } from '@/components/screen';
import { Text } from '@/components/text';
import { usePinGate } from '@/hooks/use-pin-gate';
import { useGame } from '@/store/game-store';

export function Vote() {
  const { data, session, chooseVote, revealOutcome, abortRound } = useGame();
  const { ask, overlay } = usePinGate(data.settings.pin);

  return (
    <View style={{ flex: 1 }}>
      <Screen>
        <Card>
          <Text size={24} weight="800" center>
            من هو المحتال؟
          </Text>
          <Text muted center>
            صوّتوا معاً، ثم اختر اللاعب الذي حصل على أكثر الأصوات.
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' }}>
            {session.players.map((player) => (
              <Chip
                key={player}
                role="radio"
                label={player}
                selected={session.voted === player}
                onPress={() => chooseVote(player)}
              />
            ))}
          </View>
        </Card>
        <Button
          title="اكشف النتيجة"
          disabled={!session.voted}
          onPress={() => ask('كشف النتيجة', revealOutcome)}
        />
        <Button
          title="إلغاء الجولة"
          variant="ghost"
          small
          onPress={() => ask('إلغاء الجولة', abortRound)}
        />
      </Screen>
      {overlay}
    </View>
  );
}
