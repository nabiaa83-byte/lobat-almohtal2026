import { useState } from 'react';
import { Pressable, Switch, TextInput, View } from 'react-native';

import { Button } from '@/components/button';
import { Card } from '@/components/card';
import { Chip } from '@/components/chip';
import { Screen } from '@/components/screen';
import { Text } from '@/components/text';
import { MAX_PLAYERS, MIN_PLAYERS, PIN_LENGTH, SPEAK_OPTIONS } from '@/constants';
import { CATEGORIES, CATEGORY_IDS, type CategoryId } from '@/constants/words';
import { useGame } from '@/store/game-store';
import { colors } from '@/theme';

export function Setup() {
  const { data, updateSettings, startRound } = useGame();
  const settings = data.settings;
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const allSelected = settings.categories.length === CATEGORY_IDS.length;

  const problem =
    settings.players.length < MIN_PLAYERS
      ? `أضف ${MIN_PLAYERS} لاعبين على الأقل`
      : settings.pin.length !== PIN_LENGTH
        ? `اختر رمز الحكم (${PIN_LENGTH} أرقام)`
        : '';

  function addPlayer() {
    const clean = name.trim().replace(/\s+/g, ' ');
    if (!clean) return;
    if (settings.players.includes(clean)) {
      setError('هذا الاسم مضاف مسبقاً');
      return;
    }
    if (settings.players.length >= MAX_PLAYERS) {
      setError(`الحد الأقصى ${MAX_PLAYERS} لاعباً`);
      return;
    }
    updateSettings({ players: [...settings.players, clean] });
    setName('');
    setError('');
  }

  function removePlayer(player: string) {
    updateSettings({ players: settings.players.filter((p) => p !== player) });
    setError('');
  }

  function toggleCategory(id: CategoryId) {
    const selected = settings.categories.includes(id);
    if (selected && settings.categories.length === 1) return; // فئة واحدة على الأقل
    updateSettings({
      categories: selected
        ? settings.categories.filter((c) => c !== id)
        : [...settings.categories, id],
    });
  }

  return (
    <Screen>
      <Card>
        <Text size={20} weight="700">
          اللاعبون ({settings.players.length}/{MAX_PLAYERS})
        </Text>

        {settings.players.length === 0 ? (
          <Text muted>أضف أسماء اللاعبين. تُحفظ الأسماء للجولات القادمة.</Text>
        ) : (
          settings.players.map((player, i) => (
            <View
              key={player}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 12,
              }}>
              <Text weight="600" style={{ flex: 1 }}>
                {i + 1}. {player}
              </Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`حذف ${player}`}
                hitSlop={12}
                onPress={() => removePlayer(player)}>
                <Text color={colors.danger} weight="700">
                  حذف
                </Text>
              </Pressable>
            </View>
          ))
        )}

        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <TextInput
            value={name}
            onChangeText={(text) => {
              setName(text);
              setError('');
            }}
            onSubmitEditing={addPlayer}
            submitBehavior="submit"
            returnKeyType="done"
            placeholder="اسم اللاعب"
            placeholderTextColor={colors.secondaryLabel}
            maxLength={20}
            style={{
              flex: 1,
              height: 48,
              borderRadius: 14,
              borderCurve: 'continuous',
              paddingHorizontal: 14,
              fontSize: 17,
              textAlign: 'right',
              color: colors.label,
              backgroundColor: colors.background,
            }}
          />
          <View style={{ width: 90 }}>
            <Button title="إضافة" small onPress={addPlayer} disabled={name.trim().length === 0} />
          </View>
        </View>
        {error ? (
          <Text color={colors.danger} selectable>
            {error}
          </Text>
        ) : null}
      </Card>

      <Card>
        <Text size={20} weight="700">
          الفئات
        </Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          <Chip
            label="الكل"
            selected={allSelected}
            onPress={() => updateSettings({ categories: [...CATEGORY_IDS] })}
          />
          {CATEGORIES.map((category) => (
            <Chip
              key={category.id}
              label={`${category.label} · ${category.words.length}`}
              selected={settings.categories.includes(category.id)}
              onPress={() => toggleCategory(category.id)}
            />
          ))}
        </View>
      </Card>

      <Card>
        <Text size={20} weight="700">
          وقت كل لاعب في النقاش
        </Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {SPEAK_OPTIONS.map((seconds) => (
            <Chip
              key={seconds}
              role="radio"
              label={`${seconds} ثانية`}
              selected={settings.speakSeconds === seconds}
              onPress={() => updateSettings({ speakSeconds: seconds })}
            />
          ))}
        </View>
      </Card>

      <Card>
        <Text size={20} weight="700">
          خيارات الحكم
        </Text>

        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Text style={{ flex: 1 }}>المحتال يعرف الفئة</Text>
          <Switch
            value={settings.impostorSeesCategory}
            onValueChange={(value) => updateSettings({ impostorSeesCategory: value })}
            trackColor={{ true: colors.accent }}
          />
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Text style={{ flex: 1 }}>طلب الرمز عند كل انتقال بين اللاعبين</Text>
          <Switch
            value={settings.lockBetweenPlayers}
            onValueChange={(value) => updateSettings({ lockBetweenPlayers: value })}
            trackColor={{ true: colors.accent }}
          />
        </View>

        <Text muted size={15}>
          رمز الحكم يفتح الانتقال بين اللاعبين، وبدء التصويت، وكشف النتيجة، حتى لا يرى أحد كلمة غيره.
        </Text>
        <TextInput
          value={settings.pin}
          onChangeText={(text) =>
            updateSettings({ pin: text.replace(/\D/g, '').slice(0, PIN_LENGTH) })
          }
          keyboardType="number-pad"
          secureTextEntry
          maxLength={PIN_LENGTH}
          placeholder="رمز الحكم"
          placeholderTextColor={colors.secondaryLabel}
          accessibilityLabel="رمز الحكم"
          style={{
            height: 52,
            borderRadius: 14,
            borderCurve: 'continuous',
            fontSize: 24,
            textAlign: 'center',
            letterSpacing: 8,
            color: colors.label,
            backgroundColor: colors.background,
          }}
        />
      </Card>

      {problem ? (
        <Text muted center>
          {problem}
        </Text>
      ) : null}
      <Button title="ابدأ الجولة" disabled={problem !== ''} onPress={() => startRound(settings.players)} />
    </Screen>
  );
}
