import { Button } from '@/components/button';
import { Card } from '@/components/card';
import { Screen } from '@/components/screen';
import { Text } from '@/components/text';
import { getCategory } from '@/constants/words';
import { useGame } from '@/store/game-store';
import { colors } from '@/theme';

/** شاشة الكشف: الكلمة السرية للاعب العادي، أو «أنت المحتال». */
export function Reveal() {
  const { data, session, hideWord } = useGame();
  const name = session.revealOrder[session.index];
  const isImpostor = name === session.impostor;
  const categoryLabel = getCategory(session.category).label;

  return (
    <Screen center>
      <Card>
        <Text muted center>
          {name}
        </Text>
        {isImpostor ? (
          <>
            <Text size={40} weight="800" center color={colors.danger}>
              أنت المحتال!
            </Text>
            <Text muted center>
              حاول أن تعرف الكلمة من كلام الآخرين دون أن تكشف نفسك.
            </Text>
            {data.settings.impostorSeesCategory ? (
              <Text weight="700" center selectable>
                الفئة: {categoryLabel}
              </Text>
            ) : null}
          </>
        ) : (
          <>
            <Text muted center>
              الكلمة السرية
            </Text>
            <Text size={44} weight="800" center selectable adjustsFontSizeToFit numberOfLines={2}>
              {session.word}
            </Text>
            <Text muted center>
              الفئة: {categoryLabel}
            </Text>
          </>
        )}
      </Card>
      <Button title="أخفِ الكلمة" onPress={hideWord} />
    </Screen>
  );
}
