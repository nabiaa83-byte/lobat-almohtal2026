import { Button } from '@/components/button';
import { Card } from '@/components/card';
import { Screen } from '@/components/screen';
import { Text } from '@/components/text';
import { POINTS_CAUGHT, POINTS_ESCAPED } from '@/constants';
import { getCategory } from '@/constants/words';
import { useGame } from '@/store/game-store';
import { colors } from '@/theme';

export function Outcome() {
  const { session, finishRound } = useGame();
  const caught = session.voted === session.impostor;

  return (
    <Screen center>
      <Card>
        <Text size={30} weight="800" center color={caught ? colors.success : colors.danger}>
          {caught ? 'كُشف المحتال!' : 'نجا المحتال!'}
        </Text>
        <Text size={20} weight="700" center selectable>
          المحتال: {session.impostor}
        </Text>
        <Text center selectable>
          الكلمة: {session.word} ({getCategory(session.category).label})
        </Text>
        <Text muted center selectable>
          صوّت الجميع على: {session.voted}
        </Text>
        <Text muted center>
          {caught
            ? `يحصل كل لاعب عدا المحتال على ${POINTS_CAUGHT} نقطة.`
            : `يحصل ${session.impostor} على ${POINTS_ESCAPED} نقطتين.`}
        </Text>
      </Card>
      <Button title="احفظ النتيجة وابدأ جولة جديدة" onPress={finishRound} />
    </Screen>
  );
}
