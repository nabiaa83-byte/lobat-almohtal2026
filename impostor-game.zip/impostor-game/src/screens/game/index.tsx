import { useGame } from '@/store/game-store';

import { Discuss } from './discuss';
import { Lock } from './lock';
import { Outcome } from './outcome';
import { Pass } from './pass';
import { Ready } from './ready';
import { Reveal } from './reveal';
import { Setup } from './setup';
import { Vote } from './vote';

/** يعرض الشاشة المناسبة لمرحلة الجولة الحالية. */
export function Game() {
  const { session } = useGame();

  switch (session.phase) {
    case 'setup':
      return <Setup />;
    case 'pass':
      return <Pass />;
    case 'reveal':
      return <Reveal />;
    case 'lock':
      return <Lock />;
    case 'ready':
      return <Ready />;
    case 'discuss':
      return <Discuss />;
    case 'vote':
      return <Vote />;
    case 'outcome':
      return <Outcome />;
  }
}
