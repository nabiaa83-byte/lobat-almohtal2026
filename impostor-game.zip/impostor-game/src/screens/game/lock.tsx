import { PinPad } from '@/components/pin-pad';
import { Screen } from '@/components/screen';
import { useGame } from '@/store/game-store';

/** قفل الانتقال بين اللاعبين: لا يمرّ الدور التالي إلا برمز الحكم. */
export function Lock() {
  const { data, session, nextPlayer } = useGame();
  const isLast = session.index + 1 >= session.revealOrder.length;

  return (
    <Screen center>
      <PinPad
        title="سلّم الهاتف للحكم"
        hint={isLast ? 'أدخل رمز الحكم لإنهاء توزيع الأدوار' : 'أدخل رمز الحكم لعرض دور اللاعب التالي'}
        expectedPin={data.settings.pin}
        onSuccess={nextPlayer}
      />
    </Screen>
  );
}
