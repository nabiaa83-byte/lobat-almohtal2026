import { Button } from '@/components/button';
import { Card } from '@/components/card';
import { Screen } from '@/components/screen';
import { Text } from '@/components/text';
import { useGame } from '@/store/game-store';

export function Ready() {
  const { data, session, startDiscussion } = useGame();

  return (
    <Screen center>
      <Card>
        <Text size={26} weight="800" center>
          تم توزيع الأدوار
        </Text>
        <Text muted center>
          {session.players.length} لاعبين عرفوا أدوارهم. يتحدث كل لاعب بدوره لمدة{' '}
          {data.settings.speakSeconds} ثانية، ثم يصوّت الجميع على المحتال.
        </Text>
      </Card>
      <Button title="ابدأ النقاش" onPress={startDiscussion} />
    </Screen>
  );
}
