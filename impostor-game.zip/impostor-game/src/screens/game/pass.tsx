import { Button } from '@/components/button';
import { Card } from '@/components/card';
import { Screen } from '@/components/screen';
import { Text } from '@/components/text';
import { useGame } from '@/store/game-store';

/** شاشة التسليم: تُظهر اسم اللاعب فقط دون أي سر. */
export function Pass() {
  const { session, showWord } = useGame();
  const name = session.revealOrder[session.index];

  return (
    <Screen center>
      <Card>
        <Text muted center>
          اللاعب {session.index + 1} من {session.revealOrder.length}
        </Text>
        <Text size={44} weight="800" center selectable adjustsFontSizeToFit numberOfLines={2}>
          {name}
        </Text>
        <Text muted center>
          سلّم الهاتف إلى {name} فقط، وتأكد أن لا أحد ينظر إلى الشاشة.
        </Text>
      </Card>
      <Button title="اكشف دوري" onPress={showWord} />
    </Screen>
  );
}
