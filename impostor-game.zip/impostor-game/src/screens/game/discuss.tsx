import { useKeepAwake } from 'expo-keep-awake';
import { useEffect, useRef, useState } from 'react';
import { View } from 'react-native';

import { Button } from '@/components/button';
import { Card } from '@/components/card';
import { Screen } from '@/components/screen';
import { Text } from '@/components/text';
import { usePinGate } from '@/hooks/use-pin-gate';
import { useGame } from '@/store/game-store';
import { colors } from '@/theme';
import { tap, warn } from '@/utils/haptics';

/** النقاش: لكل لاعب مؤقت خاص به، والحكم يتحكم بالإيقاف والتخطي والانتقال للتصويت. */
export function Discuss() {
  useKeepAwake();
  const { data, session, startVote, abortRound } = useGame();
  const { ask, overlay } = usePinGate(data.settings.pin);
  const [turn, setTurn] = useState(0);
  const [round, setRound] = useState(1);

  const order = session.speakOrder;
  const finished = turn >= order.length;
  const goToVote = () => ask('الانتقال إلى التصويت', startVote);

  return (
    <View style={{ flex: 1 }}>
      <Screen center>
        {finished ? (
          <>
            <Card>
              <Text size={26} weight="800" center>
                انتهى دور الجميع
              </Text>
              <Text muted center>
                يمكنكم جولة نقاش أخرى أو الانتقال إلى التصويت.
              </Text>
            </Card>
            <Button
              title="جولة نقاش أخرى"
              variant="secondary"
              onPress={() => {
                setTurn(0);
                setRound((r) => r + 1);
              }}
            />
            <Button title="ابدأ التصويت" onPress={goToVote} />
          </>
        ) : (
          <>
            <Card>
              <Text muted center>
                الجولة {round} · اللاعب {turn + 1} من {order.length}
              </Text>
              <Text size={40} weight="800" center selectable adjustsFontSizeToFit numberOfLines={2}>
                {order[turn]}
              </Text>
              <TurnTimer
                key={`${round}-${turn}`}
                seconds={data.settings.speakSeconds}
                onDone={() => setTurn((t) => t + 1)}
              />
              {turn + 1 < order.length ? (
                <Text muted center>
                  التالي: {order[turn + 1]}
                </Text>
              ) : null}
            </Card>
            <Button title="تخطي إلى اللاعب التالي" variant="secondary" onPress={() => setTurn((t) => t + 1)} />
            <Button title="إنهاء النقاش والتصويت" onPress={goToVote} />
          </>
        )}
        <Button
          title="إلغاء الجولة"
          variant="ghost"
          small
          onPress={() => ask('إلغاء الجولة', abortRound)}
        />
      </Screen>
      {overlay}
    </View>
  );
}

function TurnTimer({ seconds, onDone }: { seconds: number; onDone: () => void }) {
  const [left, setLeft] = useState(seconds);
  const [paused, setPaused] = useState(false);
  const endAt = useRef(0);
  const remaining = useRef(seconds * 1000);
  const doneRef = useRef(onDone);

  useEffect(() => {
    doneRef.current = onDone;
  });

  // العدّ يعتمد على الساعة لا على عدد النبضات، فلا يتأخر عند ضغط المعالج
  useEffect(() => {
    if (paused) return;
    endAt.current = Date.now() + remaining.current;
    const id = setInterval(() => {
      const ms = Math.max(0, endAt.current - Date.now());
      remaining.current = ms;
      setLeft(Math.ceil(ms / 1000));
    }, 200);
    return () => clearInterval(id);
  }, [paused]);

  useEffect(() => {
    if (left > 0 && left <= 3) tap();
  }, [left]);

  useEffect(() => {
    if (left > 0) return;
    warn();
    const id = setTimeout(() => doneRef.current(), 1200);
    return () => clearTimeout(id);
  }, [left]);

  return (
    <View style={{ alignItems: 'center', gap: 8 }}>
      <Text
        size={96}
        weight="800"
        center
        color={left <= 5 ? colors.danger : colors.label}
        style={{ fontVariant: ['tabular-nums'] }}
        accessibilityLabel={`متبقي ${left} ثانية`}>
        {left}
      </Text>
      {left > 0 ? (
        <Button
          title={paused ? 'متابعة' : 'إيقاف مؤقت'}
          variant="ghost"
          small
          onPress={() => setPaused((p) => !p)}
        />
      ) : (
        <Text weight="700" color={colors.danger} center>
          انتهى الوقت
        </Text>
      )}
    </View>
  );
}
