import 'expo-sqlite/localStorage/install';

/** تخزين بسيط للإعدادات والنتائج على الجهاز (localStorage من expo-sqlite). */
export const storage = {
  get<T>(key: string, fallback: T): T {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : fallback;
    } catch {
      return fallback;
    }
  },

  set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // فشل الحفظ لا يجب أن يوقف اللعبة
    }
  },
};
