import { POINTS_CAUGHT, POINTS_ESCAPED } from '@/constants';
import type { PlayerStats, RoundRecord } from '@/store/types';

export const emptyStats = (): PlayerStats => ({ points: 0, rounds: 0, asImpostor: 0, caught: 0 });

type RoundResult = Pick<RoundRecord, 'players' | 'impostor' | 'caught'>;

/** يضيف نتيجة جولة إلى جدول النقاط ويعيد جدولاً جديداً. */
export function applyRound(
  scores: Record<string, PlayerStats>,
  round: RoundResult,
): Record<string, PlayerStats> {
  const next = { ...scores };
  for (const name of round.players) {
    const prev = next[name] ?? emptyStats();
    const isImpostor = name === round.impostor;
    const gained = round.caught
      ? isImpostor
        ? 0
        : POINTS_CAUGHT
      : isImpostor
        ? POINTS_ESCAPED
        : 0;
    next[name] = {
      points: prev.points + gained,
      rounds: prev.rounds + 1,
      asImpostor: prev.asImpostor + (isImpostor ? 1 : 0),
      caught: prev.caught + (isImpostor && round.caught ? 1 : 0),
    };
  }
  return next;
}

/** ترتيب اللاعبين: الأكثر نقاطاً أولاً. */
export function ranking(scores: Record<string, PlayerStats>): [string, PlayerStats][] {
  return Object.entries(scores).sort(
    (a, b) => b[1].points - a[1].points || a[1].rounds - b[1].rounds || a[0].localeCompare(b[0]),
  );
}
