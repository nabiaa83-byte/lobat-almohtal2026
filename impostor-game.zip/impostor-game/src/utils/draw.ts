import { CATEGORIES, type Category, type CategoryId } from '@/constants/words';

export type Rand = () => number;

export function shuffle<T>(items: readonly T[], rand: Rand = Math.random): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function pick<T>(items: readonly T[], rand: Rand): T {
  return items[Math.floor(rand() * items.length)];
}

export type ImpostorDraw = {
  impostor: string;
  /** من أصبحوا محتالين في الدورة الحالية (بما فيهم المختار الآن). */
  done: string[];
};

/**
 * سحب عادل للمحتال: كل لاعب يصبح محتالاً مرة واحدة قبل أن يتكرر أي لاعب،
 * ولا يُختار اللاعب نفسه مرتين متتاليتين عند بداية دورة جديدة.
 */
export function drawImpostor(
  players: readonly string[],
  done: readonly string[],
  last: string | null,
  rand: Rand = Math.random,
): ImpostorDraw {
  let finished = done.filter((name) => players.includes(name));
  let pool = players.filter((name) => !finished.includes(name));

  if (pool.length === 0) {
    // انتهت الدورة: يعود الجميع إلى القرعة
    finished = [];
    pool = [...players];
  }

  const candidates = last && pool.length > 1 ? pool.filter((name) => name !== last) : pool;
  const impostor = pick(candidates, rand);
  return { impostor, done: [...finished, impostor] };
}

export type WordDraw = {
  category: CategoryId;
  word: string;
  /** مفاتيح الكلمات المستخدمة في الدورة الحالية. */
  used: string[];
};

const wordKey = (category: CategoryId, word: string) => `${category}:${word}`;

/**
 * سحب كلمة دون تكرار حتى تُستهلك كل كلمات الفئات المختارة.
 * تُختار الفئة بالتساوي ثم الكلمة، فلا تطغى الفئات الكبيرة على الصغيرة.
 */
export function drawWord(
  categories: readonly CategoryId[],
  used: readonly string[],
  rand: Rand = Math.random,
): WordDraw {
  const chosen = CATEGORIES.filter((c) => categories.includes(c.id));
  const selected: readonly Category[] = chosen.length > 0 ? chosen : CATEGORIES;

  let usedNow = [...used];
  const remaining = (c: Category) => c.words.filter((w) => !usedNow.includes(wordKey(c.id, w)));

  let open = selected.filter((c) => remaining(c).length > 0);
  if (open.length === 0) {
    // استُهلكت كل الكلمات: نبدأ دورة جديدة للفئات المختارة فقط
    usedNow = usedNow.filter((k) => !selected.some((c) => k.startsWith(`${c.id}:`)));
    open = [...selected];
  }

  const category = pick(open, rand);
  const word = pick(remaining(category), rand);
  return { category: category.id, word, used: [...usedNow, wordKey(category.id, word)] };
}
