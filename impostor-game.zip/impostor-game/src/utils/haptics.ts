import * as Haptics from 'expo-haptics';

const supported = () => process.env.EXPO_OS !== 'web';
const ignore = () => {};

export function tap() {
  if (supported()) Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(ignore);
}

export function warn() {
  if (supported()) {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(ignore);
  }
}

export function fail() {
  if (supported()) {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(ignore);
  }
}
