import { Color } from 'expo-router';
import { Platform } from 'react-native';

/**
 * ألوان دلالية تتكيّف تلقائياً مع الوضع الفاتح والداكن:
 * UIKit على iOS وMaterial 3 الديناميكي على أندرويد، ولون ثابت للويب.
 */
export const colors = {
  label: Platform.select({
    ios: Color.ios.label,
    android: Color.android.dynamic.onSurface,
    default: '#000000',
  })!,
  secondaryLabel: Platform.select({
    ios: Color.ios.secondaryLabel,
    android: Color.android.dynamic.onSurfaceVariant,
    default: '#3c3c43',
  })!,
  separator: Platform.select({
    ios: Color.ios.separator,
    android: Color.android.dynamic.outlineVariant,
    default: '#c6c6c8',
  })!,
  background: Platform.select({
    ios: Color.ios.systemBackground,
    android: Color.android.dynamic.surface,
    default: '#ffffff',
  })!,
  card: Platform.select({
    ios: Color.ios.secondarySystemBackground,
    android: Color.android.dynamic.surfaceVariant,
    default: '#f2f2f7',
  })!,

  // ألوان اللعبة (ثابتة، مقروءة في الوضعين)
  accent: '#7C3AED',
  danger: '#E5484D',
  success: '#2BA26B',
};
