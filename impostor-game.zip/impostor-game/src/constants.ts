export const MIN_PLAYERS = 3;
export const MAX_PLAYERS = 20;
export const PIN_LENGTH = 4;

/** خيارات وقت كل لاعب في النقاش (بالثواني). */
export const SPEAK_OPTIONS = [15, 30, 45, 60, 90] as const;

/** أقصى عدد جولات محفوظة في السجل. */
export const HISTORY_LIMIT = 100;

/** نقاط كل لاعب (عدا المحتال) عند كشف المحتال. */
export const POINTS_CAUGHT = 1;

/** نقاط المحتال عندما ينجو من الكشف. */
export const POINTS_ESCAPED = 2;
